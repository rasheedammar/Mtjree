<?php

// Register the REST API endpoint
add_action('rest_api_init', function () {
    register_rest_route('custom/v1', '/update_status', array(
        'methods' => 'POST',
        'callback' => 'handle_update_status_webhook',
    ));
});

// Callback function to handle the webhook
function handle_update_status_webhook(WP_REST_Request $request) {
    $params = json_decode($request->get_body(), true);
    
    $order_id = $params['order_id'];
    $status_completed = $params['new_status']; // assuming this is a boolean parameter for payment status

    // Log the input parameters
    error_log("Webhook called with parameters: " . print_r($params, true));

    // Determine $new_status based on $status_completed
    $new_status = $status_completed ? 'processing' : 'pending_payment';

    if ($order_id) {
        // Update order status
        $order = wc_get_order($order_id);
        if ($order) {
            $order->update_status($new_status);
            error_log("Order status updated for order_id: $order_id to status: $new_status");
            return new WP_REST_Response('Order status updated', 200);
        } else {
            return new WP_REST_Response('Invalid order ID', 400);
        }
    }

    return new WP_REST_Response('Required parameters not provided', 400);
}