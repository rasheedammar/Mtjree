<?php
if (!defined('ABSPATH')) {
    exit;
}

// إضافة صفحة الإعدادات
add_action('admin_menu', 'mtjree_add_admin_page');
function mtjree_add_admin_page() {
    add_menu_page(
        'Mtjree Company Settings',
        'Mtjree Settings',
        'manage_options',
        'mtjree-settings',
        'mtjree_settings_page',
        'dashicons-admin-settings',
        100
    );
}

// إضافة السجلات الضرورية في جدول الإعدادات
function mtjree_ensure_default_settings() {
    global $wpdb;
    $table = "{$wpdb->prefix}mtjree_company_db";
    $row = $wpdb->get_row("SELECT * FROM $table WHERE id = 1", ARRAY_A);

    if (!$row) {
        $wpdb->insert($table, ['id' => 1]);
    }
}

// استدعاء وظيفة إنشاء الإعدادات الافتراضية عند تهيئة صفحة الإدارة
add_action('admin_init', 'mtjree_ensure_default_settings');

// عرض صفحة الإعدادات
function mtjree_settings_page() {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        global $wpdb;
        $table = $wpdb->prefix . 'mtjree_company_db';

        $test_mode = isset($_POST['test_mode']) ? 1 : 0;
        $success_page = sanitize_text_field($_POST['redirect_succes_page']);
        $fail_page = sanitize_text_field($_POST['redirect_fail_page']);
        $vendor_name = sanitize_text_field($_POST['vendor_name']);
        $api_key = sanitize_text_field($_POST['api_key']);
        $logo_url = sanitize_text_field($_POST['logo_url']);

        $wpdb->update(
            $table,
            [
                'enable_test_mode' => $test_mode,
                'redirect_succes_page' => $success_page,
                'redirect_fail_page' => $fail_page,
                'vendor_name' => $vendor_name,
                'api_key' => $api_key,
                'logo_url' => $logo_url,
            ],
            ['id' => 1]
        );

        echo '<div class="updated"><p>Settings saved!</p></div>';
    }
    mtjree_activate_plugin();
    global $wpdb;
    $table = $wpdb->prefix . 'mtjree_company_db';
    $row = $wpdb->get_row("SELECT * FROM $table WHERE id = 1", ARRAY_A);
    
    $test_mode = $row['enable_test_mode'] ? 'checked' : '';
    $pages = get_pages();
    // test
    // $plugin_file = plugin_dir_path(__FILE__) . 'main.php';
    // $plugin_data = get_file_data($plugin_file, ['Version' => 'Version']);
    // $current_version = $plugin_data['Version'];
    // echo '<script>console.log("'.$current_version.'");</script>';
    ?>
    <div class="wrap">
        <h1>Mtjree Settings</h1>
        <form method="POST">
            <table class="form-table">
                <tr>
                    <th scope="row">Enable Test Mode</th>
                    <td><input type="checkbox" name="test_mode" <?php echo $test_mode; ?>></td>
                </tr>
                <tr>
                    <th scope="row">Vendor Name</th>
                    <td><input type="text" name="vendor_name" value="<?php echo esc_attr($row['vendor_name']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row">API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr($row['api_key']); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row">Logo</th>
                    <td>
                        <input type="hidden" name="logo_url" id="logo_url" value="<?php echo esc_attr($row['logo_url']); ?>">
                        <button type="button" class="button" id="upload_logo_button">Upload Logo</button>
                        <div id="logo_preview" style="margin-top: 10px;">
                            <?php if (!empty($row['logo_url'])): ?>
                                <img src="<?php echo esc_url($row['logo_url']); ?>" alt="Logo" style="max-width: 150px;">
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Redirect Success Page</th>
                    <td>
                        <select name="redirect_succes_page">
                            <?php foreach ($pages as $page): ?>
                                <option value="<?php echo esc_url(get_permalink($page->ID)); ?>"
                                    <?php selected($row['redirect_succes_page'], get_permalink($page->ID)); ?>>
                                    <?php echo esc_html($page->post_title); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Redirect Fail Page</th>
                    <td>
                        <select name="redirect_fail_page">
                            <?php foreach ($pages as $page): ?>
                                <option value="<?php echo esc_url(get_permalink($page->ID)); ?>"
                                    <?php selected($row['redirect_fail_page'], get_permalink($page->ID)); ?>>
                                    <?php echo esc_html($page->post_title); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Settings'); ?>
        </form>
    </div>
    <script>
        jQuery(document).ready(function ($) {
            var mediaUploader;
            $('#upload_logo_button').click(function (e) {
                e.preventDefault();
                if (mediaUploader) {
                    mediaUploader.open();
                    return;
                }
                mediaUploader = wp.media({
                    title: 'Select Logo',
                    button: {
                        text: 'Use this logo'
                    },
                    multiple: false
                });
                mediaUploader.on('select', function () {
                    var attachment = mediaUploader.state().get('selection').first().toJSON();
                    $('#logo_url').val(attachment.url);
                    $('#logo_preview').html('<img src="' + attachment.url + '" alt="Logo" style="max-width: 150px;">');
                });
                mediaUploader.open();
            });
        });
    </script>
    <?php
}

// تسجيل API Route
add_action('rest_api_init', function () {
    register_rest_route('mtjree/v1', '/update', [
        'methods' => 'POST',
        'callback' => 'mtjree_handle_update',
        'permission_callback' => '__return_true',
    ]);
});

// وظيفة معالجة التحديث
function mtjree_handle_update(WP_REST_Request $request) {
    global $wpdb;

    $table = "{$wpdb->prefix}mtjree_company_updates";

    // استخراج الإصدار الحالي للبلجن
    $plugin_file = plugin_basename(__FILE__);
    $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file);
    $current_version = $plugin_data['Version'];

    $new_version_id = $request->get_param('new_version_id');
    $message = $request->get_param('message');
    $message_expire_at = $request->get_param('message_expire_at');

    // تحقق من وجود الإصدار الجديد
    if (!empty($new_version_id)){
    if (version_compare($current_version, $new_version_id, '<')) {
        $wpdb->insert($table, [
            'new_version_id' => sanitize_text_field($new_version_id),
            'message' => sanitize_text_field($message),
            'message_expire_at' => sanitize_text_field($message_expire_at),
        ]);

        return new WP_REST_Response(['status' => 'success', 'message' => 'Update stored successfully.'], 200);
    }
}
else{
    $wpdb->insert($table, [
        'new_version_id' => sanitize_text_field($new_version_id),
        'message' => sanitize_text_field($message),
        'message_expire_at' => sanitize_text_field($message_expire_at),
    ]);
}
}

// إضافة إشعارات إلى واجهة الإدارة
add_action('admin_notices', 'mtjree_display_notifications');

function mtjree_display_notifications() {
    global $wpdb;

    $table = $wpdb->prefix . 'mtjree_company_updates';
    $current_time = current_time('mysql');
    // update messages
    $plugin_file = plugin_dir_path(__FILE__) . 'main.php';
    $plugin_data = get_file_data($plugin_file, ['Version' => 'Version']);
    $current_version = $plugin_data['Version'];
    $update_messages_version = $wpdb->get_results("SELECT * FROM $table WHERE message_expire_at > '$current_time'");
    // جلب الرسائل غير المنتهية
    $messages_normal = $wpdb->get_results("SELECT * FROM $table WHERE new_version_id > '$current_version'");
    $messages = array_merge($update_messages_version, $messages_normal);
    $unique_messages = [];
    $unique_ids = [];

    foreach ($messages as $message) {
        if (!in_array($message->id, $unique_ids)) {
            $unique_ids[] = $message->id;
            $unique_messages[] = $message;
        }
    }

    $messages = $unique_messages;
    // عرض الرسائل
    foreach ($messages as $message) {
        echo '<div class="notice notice-info is-dismissible" style="border-left: 4px solid #0073aa; padding: 12px;">';
        echo '<p style="font-size: 14px; color: #0073aa;">' . esc_html($message->message) . '</p>';
        echo '</div>';
    }

    // حذف الرسائل المنتهية
    $wpdb->query("DELETE FROM $table WHERE message_expire_at <= '$current_time' AND new_version_id <= '$current_version'");
    $wpdb->query("DELETE FROM $table WHERE new_version_id <= '$current_version'");
}

