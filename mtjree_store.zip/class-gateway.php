<?php
    // add dynamic url to logo
class My_Custom_Gateway extends WC_Payment_Gateway {
  
    // Constructor method
    public function __construct() {
        $this->id                 = 'my_custom_gateway';
        $this->method_title       = __('Credit Card', 'my-custom-gateway');
        $this->method_description = __('Accept payments through Credit Card', 'my-custom-gateway');
        // Other initialization code goes here
        
        $this->init_form_fields();
        $this->init_settings();
        
        // Add include_once for custom-order-status-handler.php
        include_once plugin_dir_path(__FILE__) . 'custom-order-status-handler.php';

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    }
    
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __('Enable/Disable', 'my-custom-gateway'),
                'type'    => 'checkbox',
                'label'   => __('Enable My Custom Gateway', 'my-custom-gateway'),
                'default' => 'yes',
            ),
            // Add more settings fields as needed
        );
    }
    
    // Process the payment
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);
        // Get order data

        $bytes = random_bytes(8);

        $randomString = bin2hex($bytes);

        // handle phone num
        $billing_phone = $order->get_billing_phone();
        if (empty($billing_phone)) {
        $billing_phone = '';
        }
        // handling available currency
        $order_currency = $order->get_currency();
        $supported_currencies = array('KWD', 'USD', 'SAR', 'AED', 'QAR', 'BHD', 'OMR', 'EGP', 'EUR', 'GBP');
        if (!in_array($order_currency, $supported_currencies)) {
        wc_add_notice(__('not supported currency', 'text-domain'), 'error');
        return; 
        }
        // DB_mtjree_data
        global $wpdb;
        $table = $wpdb->prefix . 'mtjree_company_db';
        $row = $wpdb->get_row("SELECT * FROM $table WHERE id = 1", ARRAY_A);
        $fail_page = !empty($row['redirect_fail_page']) ? $row['redirect_fail_page'] : wc_get_cart_url();
        $order_data = [
            'order_id' => $order_id,
            'total' => $order->get_total(),
            'shop_type' => 'wordpress', // Always 'wordpress' if using WooCommerce
            'shop_url' => add_query_arg('empty_cart', 'true', wc_get_cart_url()), // empty cart short code
            'fail_url' => $fail_page,
            'currency' => $order->get_currency(),
            'email' => $order->get_billing_email(),
            'first_name'=>$order->get_billing_first_name(),
            'last_name' =>$order->get_billing_last_name(),
            'country' => $order->get_billing_country(),
            'city'=> $order->get_billing_city(),
            'state_cou'=>$order->get_billing_state(),
            'billing_address'=>$order->get_billing_address_1(),
            'postcode'=>$order->get_billing_postcode(),
            'hookUrl' => rest_url('custom/v1/update_status'),
            'customer_id' => $order->get_customer_id(), // Get customer ID
            'timestamp'=>$randomString,
            'phone'=>$billing_phone,
            'vendor_name' => $row['vendor_name'],
            'logo_url' => $row['logo_url'],
            'test_mode' => !empty($row['enable_test_mode']) ? TRUE : FALSE,
        ];
        
        // Send order to server and check response
        // just replace "demo.qrstore.sa" with new domain name
        $response = wp_remote_post('https://mtjree.link/wp-json/custom/v1/proxy', [
            'method' => 'POST',
            'body' => json_encode($order_data),
            'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $row['api_key'],
            ],
            'timeout' => 30,
        ]);
    
        // Check response
        if (is_wp_error($response)) {
            $error_code = $response->get_error_code();
            $expected_errors = ['invalid_url', 'domain_mismatch', 'no_payment_methods', 'request_failed'];
            
            if (!in_array($error_code, $expected_errors, true)) {
                $response2 = wp_remote_post('https://mtjree.link/wp-json/custom/v1/proxy', [
                    'method' => 'POST',
                    'body' => json_encode($order_data),
                    'headers' => [
                        'Content-Type' => 'application/json',
                        'Authorization'=> 'Bearer ' . $row['api_key'],
                    ],
                    'timeout' => 30,
                ]);
                $response_code2 = wp_remote_retrieve_response_code($response2);
                $response_body2 = wp_remote_retrieve_body($response2);
                $response_data2 = json_decode($response_body2, true);
                if ($response_code2 === 200) {
                    // If response is approved, complete payment and redirect user
                    if (isset($response_data['url'])) {
                        return [
                            'result' => 'success',
                            'redirect' => $response_data2['url'],
                        ];
                    } else {
                        wc_add_notice(__('Unexpected error in payment processing, please try again later.', 'my-custom-gateway'), 'error');
                        return;
                    }
                }
            } else {
                $error_message = $response->get_error_message();
                wc_add_notice(sprintf(__('Error: %s', 'my-custom-gateway'), $error_message), 'error');
            }
            
            return;
        }


        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $response_data = json_decode($response_body, true);
    
        if ($response_code === 200) {
            // If response is approved, complete payment and redirect user
            if (isset($response_data['url'])) {
                return [
                    'result' => 'success',
                    'redirect' => $response_data['url'],
                ];
            } else {
                wc_add_notice(__('No redirect URL received from server.', 'my-custom-gateway'), 'error');
                return;
            }
        } else if ($response_code === 400) {
            // If response is declined, add error notice
            wc_add_notice(__('Payment declined, please try again.', 'my-custom-gateway'), 'error');
            return;
        } else {
            // For any other case, add error notice
            wc_add_notice(__('Unexpected error in payment processing, please try again.', 'my-custom-gateway'), 'error');
            return;
        }
    }
}

// Register the gateway
function add_my_custom_gateway_class($methods) {
    $methods[] = 'My_Custom_Gateway';
    return $methods;
}
add_filter('woocommerce_payment_gateways', 'add_my_custom_gateway_class');


// add icon method
function modify_gateway_title_with_icon_gateway($title, $id) {
    if ($id === 'my_custom_gateway') {
        $title = __('Credit Card', 'my-custom-gateway');
    }
    return $title;
}
add_filter('woocommerce_gateway_title', 'modify_gateway_title_with_icon_gateway', 10, 2);

