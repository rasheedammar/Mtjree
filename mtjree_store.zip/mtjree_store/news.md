# Version 4.0.0 Release Notes

## New Features

### Notification System
- Implemented a comprehensive notification system

### Enhanced Security
- Added additional security measures with API key integration

### Payment Gateway Improvements
- Added customizable return URL functionality for success/failure pages
- Implemented vendor branding features
    - Logo display capability
    - Vendor name display in payment gateway
