<?php
/*
Plugin Name: Credit Card
Description: Pay with Credit Card.
Version: 4.0.0
Author: Mtjree Store
Author URI: https://linktr.ee/mtjree
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt
Text Domain: credit-card
Domain Path: /languages
*/

add_action('plugins_loaded', 'woocommerce_myplugin', 0);
function woocommerce_myplugin(){
    if (!class_exists('WC_Payment_Gateway'))
        return; // إذا لم تكن فئة بوابة الدفع WC موجودة

    include(plugin_dir_path(__FILE__) . 'class-gateway.php');
}

add_filter('woocommerce_payment_gateways', 'add_my_custom_gateway');
function add_my_custom_gateway($gateways) {
    $gateways[] = 'My_Custom_Gateway';
    return $gateways;
}

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature 
 */
function declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}

// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'declare_cart_checkout_blocks_compatibility');

// Hook the custom function to the 'woocommerce_blocks_loaded' action
add_action('woocommerce_blocks_loaded', 'oawoo_register_order_approval_payment_method_type');

/**
 * Custom function to register a payment method type
 */
function oawoo_register_order_approval_payment_method_type() {
    // Check if the required class exists
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        return;
    }
    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'class-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function(Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register(new My_Custom_Gateway_Blocks);
        }
    );
}

// custom empty cart
// cart/?empty_cart=true/false
// then go to my-account page
add_action('template_redirect', 'empty_cart_param');
function empty_cart_param(){ 
    if (is_cart()){
        if (isset($_GET['empty_cart'])) {
            // Get total value from query parameter
            $empty_param = $_GET['empty_cart'];
            if ($empty_param === 'true') {
                // Get WooCommerce cart instance
                $cart = WC()->cart;
                
                // Empty the cart
                $cart->empty_cart();
                
                // Check for order ID in URL and update status if present
                $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
                if ($order_id > 0) {
                    error_log("Checking order status for order $order_id after payment return");
                }
                
                // get success redirect page from db
                global $wpdb;
                $table = $wpdb->prefix . 'mtjree_company_db';
                $success_page = $wpdb->get_var("SELECT redirect_succes_page FROM $table WHERE id = 1");

                // Add order_id to success page URL if available
                if ($order_id > 0) {
                    $success_page = add_query_arg('order_id', $order_id, $success_page);
                }

                wp_safe_redirect($success_page);
                exit;
            }
        }
    }
}

function my_plugin_activate() {
    $domain = site_url();

    $target_url = 'https://mtjree.link//wp-json/custom-webhook/v1/receive-plugins-activated';

    $data = array(
        'domain' => $domain,
    );

    $json_data = json_encode($data);

    $args = array(
        'method'    => 'POST',
        'body'      => $json_data,
        'headers'   => array(
            'Content-Type' => 'application/json',
        ),
        'timeout'   => 30,
    );

    $response = wp_remote_post($target_url, $args);

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log("Error sending domain: $error_message");
    }
}

register_activation_hook(__FILE__, 'my_plugin_activate');

// إضافة Action Hook لتعطيل البلجن
register_deactivation_hook(__FILE__, 'my_plugin_deactivate');

function my_plugin_deactivate() {
    $domain = site_url();

    $target_url = 'https://mtjree.link/wp-json/custom-webhook/v1/receive-plugins-deactivated';

    $data = array(
        'domain' => $domain,
    );

    $json_data = json_encode($data);

    $args = array(
        'method'    => 'POST',
        'body'      => $json_data,
        'headers'   => array(
            'Content-Type' => 'application/json',
        ),
        'timeout'   => 30,
    );

    $response = wp_remote_post($target_url, $args);

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log("Error sending domain: $error_message");
    }
}

add_action('template_redirect', 'check_for_phone_error_on_cart_page');

function check_for_phone_error_on_cart_page() {
    // Only proceed if it's the cart page
    if (is_cart() && isset($_GET['error_name']) && $_GET['error_name'] === 'phone_is_required') {
        // Add an action to display the error before the cart
        add_action('wp_footer', 'display_phone_required_error_message');
    }
}

function display_phone_required_error_message() {
    echo '<script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function() {
            let cartContainer = document.querySelector(".woocommerce-cart");
            if (cartContainer) {
                let errorMsg = document.createElement("div");
                errorMsg.className = "woocommerce-error";
                errorMsg.textContent = "Phone field is required";
                cartContainer.insertBefore(errorMsg, cartContainer.firstChild);
            }
        });
    </script>';
}

register_activation_hook(__FILE__, 'mtjree_activate_plugin');
add_action('upgrader_process_complete', 'mtjree_activate_plugin', 10, 2);
function mtjree_activate_plugin() {
    global $wpdb;

    $table1 = $wpdb->prefix . 'mtjree_company_db';
    $charset_collate = $wpdb->get_charset_collate();
    $sql1 = "CREATE TABLE IF NOT EXISTS $table1 (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        enable_test_mode BOOLEAN DEFAULT 0,
        logo_url VARCHAR(255),
        vendor_name VARCHAR(255),
        api_key VARCHAR(255),
        redirect_succes_page VARCHAR(255),
        redirect_fail_page VARCHAR(255)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql1);

    $table2 = $wpdb->prefix . 'mtjree_company_updates';
    $sql2 = "CREATE TABLE IF NOT EXISTS $table2 (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        new_version_id VARCHAR(50),
        message TEXT,
        message_expire_at DATETIME
    ) $charset_collate;";
    dbDelta($sql2);
}

// تضمين ملف صفحة الإدارة
require_once plugin_dir_path(__FILE__) . 'admin_update_page.php';

// تضمين ملف معالج حالة الطلب المخصص
include_once plugin_dir_path(__FILE__) . 'custom-order-status-handler.php';

?>
