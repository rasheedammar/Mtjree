<?php
/*
Plugin Name: Credit Card
Description: Pay with Credit Card.
Version: 4.0.0
Author: Mtjree Store
Author URI: https://linktr.ee/mtjree
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt
Text Domain: credit-card
Domain Path: /languages
*/

add_action('plugins_loaded', 'woocommerce_myplugin', 0);
function woocommerce_myplugin(){
    if (!class_exists('WC_Payment_Gateway'))
        return; // إذا لم تكن فئة بوابة الدفع WC موجودة

    include(plugin_dir_path(__FILE__) . 'class-gateway.php');
}

add_filter('woocommerce_payment_gateways', 'add_my_custom_gateway');
function add_my_custom_gateway($gateways) {
    $gateways[] = 'My_Custom_Gateway';
    return $gateways;
}

/**
 * Custom function to declare compatibility with cart_checkout_blocks feature 
 */
function declare_cart_checkout_blocks_compatibility() {
    // Check if the required class exists
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        // Declare compatibility for 'cart_checkout_blocks'
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
    }
}

// تضمين ملف معالج حالة الطلب المخصص
include_once plugin_dir_path(__FILE__) . 'custom-order-status-handler.php';
// Hook the custom function to the 'before_woocommerce_init' action
add_action('before_woocommerce_init', 'declare_cart_checkout_blocks_compatibility');

// Hook the custom function to the 'woocommerce_blocks_loaded' action
add_action('woocommerce_blocks_loaded', 'oawoo_register_order_approval_payment_method_type');

/**
 * Custom function to register a payment method type
 */
function oawoo_register_order_approval_payment_method_type() {
    // Check if the required class exists
    if (!class_exists('Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        return;
    }
    // Include the custom Blocks Checkout class
    require_once plugin_dir_path(__FILE__) . 'class-block.php';
    // Hook the registration function to the 'woocommerce_blocks_payment_method_type_registration' action
    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function(Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry) {
            // Register an instance of My_Custom_Gateway_Blocks
            $payment_method_registry->register(new My_Custom_Gateway_Blocks);
        }
    );
}

// custom empty cart
// cart/?empty_cart=true/false
// then go to my-account page
add_action('template_redirect', 'empty_cart_param');
function empty_cart_param(){ 
    error_log('MTJREE DEBUG: empty_cart_param function called');
    
    if (is_cart()){
        error_log('MTJREE DEBUG: Current page is cart');
        
        // Debug all parameters in the URL
        error_log('MTJREE DEBUG: Displaying all URL parameters:');
        foreach ($_GET as $param_name => $param_value) {
            if (is_array($param_value)) {
                error_log('MTJREE DEBUG: Parameter ' . $param_name . ' = ' . json_encode($param_value));
            } else {
                error_log('MTJREE DEBUG: Parameter ' . $param_name . ' = ' . $param_value);
            }
        }
        
        if (isset($_GET['empty_cart'])) {
            error_log('MTJREE DEBUG: empty_cart parameter is set');
            
            // Get total value from query parameter
            $empty_param = $_GET['empty_cart'];
            error_log('MTJREE DEBUG: empty_cart value: ' . $empty_param);
            
            if ($empty_param === 'true') {
                // Check for order_id in multiple formats
                // First try the standard parameter name
                $order_id = 0;
                if (isset($_GET['order_id'])) {
                    $order_id = intval($_GET['order_id']);
                    error_log('MTJREE DEBUG: Found order_id parameter: ' . $order_id);
                }
                // If not found, check for WordPress encoded version with amp; prefix
                elseif (isset($_GET['amp;order_id'])) {
                    $order_id = intval($_GET['amp;order_id']);
                    error_log('MTJREE DEBUG: Found amp;order_id parameter: ' . $order_id);
                }
                
                error_log('MTJREE DEBUG: Order ID from URL: ' . $order_id);
                
                // Get WooCommerce cart instance
                $cart = WC()->cart;
                error_log('MTJREE DEBUG: WooCommerce cart instance obtained');
                
                // Empty the cart
                $cart->empty_cart();
                error_log('MTJREE DEBUG: Cart emptied successfully');
                
                // Check for order ID in URL and update status if present
                if (!empty($order_id)) {
                    error_log('MTJREE DEBUG: Valid order_id detected, updating order status');
                    // Call the handler here
                    fetch_and_update_order_status_from_link($order_id);
                    error_log('MTJREE DEBUG: Order status update function called for order ID: ' . $order_id);
                } else {
                    error_log('MTJREE DEBUG: No valid order_id found in URL');
                }
                
                // get success redirect page from db
                global $wpdb;
                $table = $wpdb->prefix . 'mtjree_company_db';
                error_log('MTJREE DEBUG: Querying database table: ' . $table);
                
                $success_page = $wpdb->get_var("SELECT redirect_succes_page FROM $table WHERE id = 1");
                error_log('MTJREE DEBUG: Success page URL from database: ' . ($success_page ?: 'not found'));
                
                // Add order_id to success page URL if available
                if ($order_id > 0) {
                    $success_page = add_query_arg('order_id', $order_id, $success_page);
                    error_log('MTJREE DEBUG: Added order_id to success page URL: ' . $success_page);
                }
                
                error_log('MTJREE DEBUG: Redirecting to: ' . $success_page);
                wp_safe_redirect($success_page);
                error_log('MTJREE DEBUG: Redirect initiated, exiting');
                exit;
            } else {
                error_log('MTJREE DEBUG: empty_cart parameter is not "true", value: ' . $empty_param);
            }
        } else {
            error_log('MTJREE DEBUG: empty_cart parameter is not set in URL');
        }
    } else {
        error_log('MTJREE DEBUG: Current page is not cart');
    }
}

// Ensure the fetch_and_update_order_status_from_link function is included

function my_plugin_activate() {
    $domain = site_url();

    $target_url = 'https://mtjree.link//wp-json/custom-webhook/v1/receive-plugins-activated';

    $data = array(
        'domain' => $domain,
    );

    $json_data = json_encode($data);

    $args = array(
        'method'    => 'POST',
        'body'      => $json_data,
        'headers'   => array(
            'Content-Type' => 'application/json',
        ),
        'timeout'   => 30,
    );

    $response = wp_remote_post($target_url, $args);

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log("Error sending domain: $error_message");
    }
}

register_activation_hook(__FILE__, 'my_plugin_activate');

// إضافة Action Hook لتعطيل البلجن
register_deactivation_hook(__FILE__, 'my_plugin_deactivate');

function my_plugin_deactivate() {
    $domain = site_url();

    $target_url = 'https://mtjree.link/wp-json/custom-webhook/v1/receive-plugins-deactivated';

    $data = array(
        'domain' => $domain,
    );

    $json_data = json_encode($data);

    $args = array(
        'method'    => 'POST',
        'body'      => $json_data,
        'headers'   => array(
            'Content-Type' => 'application/json',
        ),
        'timeout'   => 30,
    );

    $response = wp_remote_post($target_url, $args);

    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        error_log("Error sending domain: $error_message");
    }
}

add_action('template_redirect', 'check_for_phone_error_on_cart_page');

function check_for_phone_error_on_cart_page() {
    // Only proceed if it's the cart page
    if (is_cart() && isset($_GET['error_name']) && $_GET['error_name'] === 'phone_is_required') {
        // Add an action to display the error before the cart
        add_action('wp_footer', 'display_phone_required_error_message');
    }
}

function display_phone_required_error_message() {
    echo '<script type="text/javascript">
        document.addEventListener("DOMContentLoaded", function() {
            let cartContainer = document.querySelector(".woocommerce-cart");
            if (cartContainer) {
                let errorMsg = document.createElement("div");
                errorMsg.className = "woocommerce-error";
                errorMsg.textContent = "Phone field is required";
                cartContainer.insertBefore(errorMsg, cartContainer.firstChild);
            }
        });
    </script>';
}

register_activation_hook(__FILE__, 'mtjree_activate_plugin');

function mtjree_activate_plugin() {
    global $wpdb;

    // --- Create/Update mtjree_company_db table ---
    $table1 = $wpdb->prefix . 'mtjree_company_db';
    $charset_collate = $wpdb->get_charset_collate();
    // Ensure all columns are present in the CREATE TABLE statement
    $sql1 = "CREATE TABLE $table1 (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        api_key varchar(255) DEFAULT '' NOT NULL,
        redirect_succes_page varchar(255) DEFAULT '' NOT NULL,
        redirect_fail_page varchar(255) DEFAULT '' NOT NULL,
        vendor_name varchar(255) DEFAULT '' NOT NULL,
        logo_url varchar(255) DEFAULT '' NOT NULL,
        enable_test_mode BOOLEAN DEFAULT 0 NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql1);

    // Ensure default row ID=1 exists after table creation/update
    $row_exists = $wpdb->get_row("SELECT id FROM $table1 WHERE id = 1");
    if (!$row_exists) {
        $wpdb->insert(
            $table1,
            array(
                'id' => 1,
                'api_key' => '',
                'redirect_succes_page' => '',
                'redirect_fail_page' => '',
                'vendor_name' => '',
                'logo_url' => '',
                'enable_test_mode' => 0,
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%d')
        );
    }

    $table2 = $wpdb->prefix . 'mtjree_company_updates';
    $sql2 = "CREATE TABLE IF NOT EXISTS $table2 (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        new_version_id VARCHAR(50),
        message TEXT,
        message_expire_at DATETIME
    ) $charset_collate;";
    dbDelta($sql2);

    // --- Create/Update custom_error_logs table ---
    // Call the function that handles DB Delta for logs
    custom_error_logger_create_table();

    // --- Log activation message ONCE ---
    // Check if this activation has already been logged recently to avoid duplicates on rapid activate/deactivate
    $transient_key = 'mtjree_activation_logged';
    if (get_transient($transient_key) === false) {
        custom_error_logger('['.date('Y-m-d H:i:s').'] [SYSTEM] [Setup] [ACTIVATE] MTJREE Plugin Activated/Updated. Tables checked/created.');
        // Set a transient to prevent re-logging for the next 60 seconds
        set_transient($transient_key, true, 60);
    }
}

/**
 * Create the database table for error logs (only contains dbDelta now)
 */
function custom_error_logger_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_error_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        timestamp DATETIME NOT NULL,
        system VARCHAR(50) NOT NULL,
        module VARCHAR(50) NOT NULL,
        order_id VARCHAR(50),
        event_type VARCHAR(100) NOT NULL,
        message TEXT NOT NULL,
        file VARCHAR(255) NOT NULL,
        line INT UNSIGNED NOT NULL,
        full_message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Error Logger Functionality - Moved from custom_error_logger plugin
/**
 * Log a message to the database
 * 
 * @param string $message The message to log
 * @return bool True on success, false on failure
 */
function custom_error_logger($message) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_error_logs';
    
    // Get trace information
    $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 2);
    $caller = isset($trace[1]['file']) ? basename($trace[1]['file']) : 'unknown';
    $line = isset($trace[1]['line']) ? $trace[1]['line'] : 0;
    
    // Parse the message to extract components if it has the standard format
    $components = array(
        'timestamp' => date('Y-m-d H:i:s'),
        'system' => 'UNKNOWN',
        'module' => 'UNKNOWN',
        'order_id' => '',
        'event_type' => '',
        'message' => $message
    );
    
    // Try to extract components from formatted messages like: [2023-04-12 14:00:00] [SUP] [StatusUpdate] [Order:123] [UPDATE_SUCCESS] Message
    if (preg_match('/\[(.*?)\]\s*\[(.*?)\]\s*\[(.*?)\](?:\s*\[Order:(.*?)\])?\s*\[(.*?)\]\s*(.*)/', $message, $matches)) {
        if (count($matches) >= 6) {
            $components['timestamp'] = $matches[1];
            $components['system'] = $matches[2];
            $components['module'] = $matches[3];
            $components['order_id'] = isset($matches[4]) ? $matches[4] : '';
            $components['event_type'] = $matches[5];
            $components['message'] = isset($matches[6]) ? $matches[6] : '';
        }
    }
    
    // Insert into database
    $result = $wpdb->insert(
        $table_name,
        array(
            'timestamp' => $components['timestamp'],
            'system' => $components['system'],
            'module' => $components['module'],
            'order_id' => $components['order_id'],
            'event_type' => $components['event_type'],
            'message' => $components['message'],
            'file' => $caller,
            'line' => $line,
            'full_message' => $message
        )
    );
    
    return $result !== false;
}

/**
 * Add admin menu page for displaying logs
 */
function custom_error_logger_menu() {
    add_menu_page(
        'Error Logs', 
        'Error Logs',
        'manage_options',
        'custom-error-logs',
        'custom_error_logger_page',
        'dashicons-warning',
        101
    );
}
add_action('admin_menu', 'custom_error_logger_menu');


function custom_error_logger_admin_enqueue($hook) {
    if ($hook != 'toplevel_page_custom-error-logs') {
        return;
    }

    // Enqueue Bootstrap CSS
    wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');

    // Enqueue DataTables CSS and JS
    wp_enqueue_style('datatables-css', 'https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css');
    wp_enqueue_script('datatables-js', 'https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js', array('jquery'), null, true);

    // Enqueue Bootstrap JS (Popper.js and Bootstrap's JavaScript)
    wp_enqueue_script('popper-js', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js', array('jquery'), null, true);
    wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery', 'popper-js'), null, true);

    // Custom CSS
    wp_enqueue_style('custom-error-logs-css', plugin_dir_url(__FILE__) . 'css/custom-error-logs.css');

    // Custom JS
    wp_enqueue_script('custom-error-logs-js', plugin_dir_url(__FILE__) . 'js/custom-error-logs.js', array('jquery', 'datatables-js', 'bootstrap-js'), null, true);
}
add_action('admin_enqueue_scripts', 'custom_error_logger_admin_enqueue');

/*
 * Admin page for displaying logs
 */
function custom_error_logger_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_error_logs';

    // Handle log clearing
    if (isset($_POST['action']) && $_POST['action'] === 'clear_logs') {
        check_admin_referer('custom_error_logger_clear_logs', 'clear_logs_nonce');

        $wpdb->query("TRUNCATE TABLE $table_name");

        // Add log entry about clearing
        custom_error_logger('['.date('Y-m-d H:i:s').'] [SYSTEM] [Admin] [MAINTENANCE] Logs cleared by admin');

        echo '<div class="notice notice-success is-dismissible"><p>All logs have been cleared.</p></div>';
    }

    // Get all logs
    $logs = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC LIMIT 10000", ARRAY_A);

    // Output HTML
    ?>
    <div class="wrap">
        <h1>Custom Error Logs</h1>

        <div class="error-log-clear">
            <form method="post" onsubmit="return confirm('Are you sure you want to clear all logs? This action cannot be undone.');">
                <?php wp_nonce_field('custom_error_logger_clear_logs', 'clear_logs_nonce'); ?>
                <input type="hidden" name="action" value="clear_logs">
                <button type="submit" class="button button-secondary" id="clear-logs-button">Clear All Logs</button>
            </form>
        </div>

        <div class="table-responsive">
            <table id="error-logs-table" class="table table-striped">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>System</th>
                        <th>Module</th>
                        <th>Order ID</th>
                        <th>Event Type</th>
                        <th>Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr data-toggle="collapse" data-target="#log-details-<?php echo $log['id']; ?>" class="accordion-toggle">
                            <td><?php echo esc_html($log['timestamp']); ?></td>
                            <td><?php echo esc_html($log['system']); ?></td>
                            <td><?php echo esc_html($log['module']); ?></td>
                            <td><?php echo esc_html($log['order_id']); ?></td>
                            <td><?php echo esc_html($log['event_type']); ?></td>
                            <td><?php echo esc_html($log['message']); ?></td>
                        </tr>
                        <tr>
                            <td colspan="6" class="hiddenRow">
                                <div class="accordian-body collapse" id="log-details-<?php echo $log['id']; ?>">
                                    <p><strong>Full Message:</strong> <?php echo esc_html($log['full_message']); ?></p>
                                    <p><strong>File:</strong> <?php echo esc_html($log['file']); ?> (line <?php echo esc_html($log['line']); ?>)</p>
                                    <p><strong>Created At:</strong> <?php echo esc_html($log['created_at']); ?></p>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        jQuery(document).ready(function($){
            $('#error-logs-table').DataTable({
                "order": [[ 0, "desc" ]]
            });
        });
    </script>
    <?php
}
?>
