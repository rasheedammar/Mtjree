<?php
/**
 * Plugin Name: Custom Order Status Handler
 * Description: Handles custom order status updates and related functionalities.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Function to update order status via REST endpoint
add_action('rest_api_init', 'register_update_order_status_endpoint');

function register_update_order_status_endpoint() {
    register_rest_route('custom/v1', '/update_order_status/', array(
        'methods'  => 'POST',
        'callback' => 'update_order_status_callback',
        'permission_callback' => '__return_true', // ควรปรับปรุงเรื่อง permission
    ));
}

function update_order_status_callback( WP_REST_Request $request ) {
    $order_id   = $request->get_param('order_id');
    $new_status = $request->get_param('new_status');

    if (!$order_id || !$new_status) {
        return new WP_REST_Response('Required parameters not provided', 400);
    }

    // Update order status
    $order = wc_get_order($order_id);
    if ($order) {
        $order->update_status($new_status);
        error_log("Order status updated for order_id: $order_id to status: $new_status");
        return new WP_REST_Response('Order status updated', 200);
    } else {
        return new WP_REST_Response('Invalid order ID', 400);
    }
}
// update for those who cannot use the above code
function ensure_updated_callback( WP_REST_Request $request ) {
    error_log('ensure_updated_callback called');
    $order_id   = $request->get_param('order_id');
    $new_status = $request->get_param('new_status');
    $user_id    = $request->get_param('user_id');

    if (!$order_id || !$new_status ) {
        return new WP_REST_Response('Missing required parameters', 400);
    }

    $order = wc_get_order($order_id);
    
    if ($order) {
        $new_status = $new_status ? 'processing' : 'pending_payment';
        // تحديث حالة الطلب
        $order->update_status($new_status);
        error_log("FROM MSUP |||| Order status updated for order_id: $order_id to status: $new_status by user: $user_id");

        return new WP_REST_Response('Order status updated', 200);
    } else {
        return new WP_REST_Response('Invalid order ID', 400);
    }
}

function register_ensure_updated_endpoint() {
    register_rest_route('custom/v1', '/ensure_updated/', array(
        'methods'  => 'GET',
        'callback' => 'ensure_updated_callback',
        'permission_callback' => '__return_true', // تأكد من استخدام التحقق المناسب للطلبات الحقيقية
    ));
}

add_action('rest_api_init', 'register_ensure_updated_endpoint');

// Add settings page
add_action('admin_menu', 'mtjree_settings_menu');

function mtjree_settings_menu() {
    add_menu_page(
        'MTJREE Settings',
        'MTJREE Settings',
        'manage_options',
        'mtjree-settings',
        'mtjree_settings_page',
        'dashicons-admin-generic'
    );
}

function mtjree_settings_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'mtjree_company_db';

    // Create the table if it doesn't exist
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            api_key varchar(255) DEFAULT '' NOT NULL,
            redirect_succes_page varchar(255) DEFAULT '' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

        // Insert a default row if the table is empty
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        if ($count == 0) {
            $wpdb->insert(
                $table_name,
                array(
                    'api_key' => '',
                    'redirect_succes_page' => '',
                )
            );
        }
    }

    // Handle update settings
    if (isset($_POST['update_settings'])) {
        $api_key = sanitize_text_field($_POST['api_key']);
        $redirect_succes_page = sanitize_text_field($_POST['redirect_succes_page']);

        $wpdb->update(
            $table_name,
            array(
                'api_key' => $api_key,
                'redirect_succes_page' => $redirect_succes_page,
            ),
            array('id' => 1)
        );
        echo '<div class="updated"><p>Settings updated successfully!</p></div>';
    }

    // Fetch settings
    $settings = $wpdb->get_row("SELECT api_key, redirect_succes_page FROM $table_name WHERE id = 1");
    $api_key = $settings->api_key ?? '';
    $redirect_succes_page = $settings->redirect_succes_page ?? '';
    ?>
    <div class="wrap">
        <h1>MTJREE Settings</h1>
        <form method="post">
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">API Key</th>
                    <td><input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text"></td>
                </tr>
                <tr valign="top">
                    <th scope="row">Redirect Success Page</th>
                    <td><input type="text" name="redirect_succes_page" value="<?php echo esc_attr($redirect_succes_page); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button('Update Settings', 'primary', 'update_settings'); ?>
        </form>
    </div>
    <?php
}

add_action('woocommerce_thankyou', 'fetch_and_update_order_status_from_link', 10, 1);

function fetch_and_update_order_status_from_link($order_id_wc) {
    // Get the original order ID sent to the proxy (you might need to retrieve this differently, maybe from order meta stored earlier?)
    // For this example, let's assume it's stored in meta. Replace 'original_main_order_id_meta_key'.
     $order_wc = wc_get_order($order_id_wc);
     if (!$order_wc) return; // Exit if order not found
     // $original_order_id = $order_wc->get_meta('original_main_order_id_meta_key', true);
     $original_order_id = $order_wc->get_id(); // Using WC order ID directly if it matches main_order_id

     if (empty($original_order_id)) {
         error_log("Original Order ID not found for WC Order ID: $order_id_wc");
         return;
     }

    global $wpdb;
    $settings_table = $wpdb->prefix . 'mtjree_company_db';
    $settings = $wpdb->get_row("SELECT api_key FROM $settings_table LIMIT 1");
    $api_key = $settings->api_key ?? null;

    if (empty($api_key)) {
         error_log("API Key not found in client settings for order $order_id_wc.");
        return;
    }

    $client_domain = parse_url(site_url(), PHP_URL_HOST); // Get current site domain
     $target_url = add_query_arg([
         'order_id' => $original_order_id,
         'domain' => $client_domain,
     ], 'https://mtjree.link/wp-json/operations-manager/v1/get-order-status');


     error_log("Attempting to fetch status for Order $original_order_id from $target_url");

    $response = wp_remote_get($target_url, [
        'timeout' => 20,
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Accept'        => 'application/json',
        ],
    ]);

    if (is_wp_error($response)) {
        error_log("Error fetching status from link for Order $order_id_wc: " . $response->get_error_message());
        return;
    }

    $http_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

     error_log("Response from get-order-status (Order $order_id_wc): Code=$http_code, Body=$body");


    if ($http_code === 200 && isset($data['status']) && $data['status'] === true) {
        // Check current status to avoid unnecessary updates
        if ($order_wc->get_status() !== 'processing' && $order_wc->get_status() !== 'completed') {
            $order_wc->update_status('processing', 'Order status updated via pull from mtjree.link.');
             error_log("Successfully updated WC Order $order_id_wc status to processing via pull.");
        } else {
             error_log("WC Order $order_id_wc already processing or completed. No update needed via pull.");
        }
    } elseif ($http_code !== 200) {
         error_log("Failed to fetch status from link for Order $order_id_wc. HTTP Code: $http_code. Response: " . ($data['message'] ?? 'Unknown error'));
    } elseif (isset($data['status']) && $data['status'] === false) {
        // Optionally update status to 'failed' or 'pending-payment' if needed
         error_log("Status from link for Order $order_id_wc is false. Current WC status: " . $order_wc->get_status());
         if ($order_wc->get_status() === 'pending') {
            // Maybe update to failed? Depends on requirements.
            // $order_wc->update_status('failed', 'Order status updated to failed via pull from mtjree.link.');
         }
    }
}

// Also check status on the success page after payment return
add_action('template_redirect', 'check_order_status_on_success_page');

function check_order_status_on_success_page() {
    global $wpdb;
    
    // Get the success page URL from the database
    $table = $wpdb->prefix . 'mtjree_company_db';
    $success_page = $wpdb->get_var("SELECT redirect_succes_page FROM $table WHERE id = 1");
    
    // If no success page defined, return
    if (empty($success_page)) {
        return;
    }
    
    // Check if we're on the success page
    $current_url_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $success_page_path = parse_url($success_page, PHP_URL_PATH);
    
    if ($current_url_path !== $success_page_path) {
        return;
    }
    
    error_log("On success page - checking for order to update status");
    
    // Try to get the order ID from URL parameters
    $order_id = 0;
    if (isset($_GET['order_id'])) {
        $order_id = intval($_GET['order_id']);
    } elseif (isset($_GET['key']) && !empty($_GET['key'])) {
        // Try to get order by order key
        $order_key = wc_clean($_GET['key']);
        $order_id = wc_get_order_id_by_order_key($order_key);
    } elseif (WC()->session) {
        // Try to get from session
        $order_id = WC()->session->get('last_order_id');
    }
    
    // If we have an order ID, check its status
    if ($order_id > 0) {
        error_log("Found order ID $order_id on success page - checking status");
        fetch_and_update_order_status_from_link($order_id);
    } else {
        error_log("No order ID found on success page to update status");
    }
}
