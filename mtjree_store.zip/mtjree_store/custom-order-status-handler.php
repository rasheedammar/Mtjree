<?php

// Ensure database table exists before querying it
function ensure_mtjree_table_exists() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'mtjree_company_db';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            api_key varchar(255) DEFAULT '' NOT NULL,
            redirect_succes_page varchar(255) DEFAULT '' NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
add_action('init', 'ensure_mtjree_table_exists');

// Add error handling for REST API endpoints
function safe_update_order_status_callback(WP_REST_Request $request) {
    try {
        $order_id = $request->get_param('order_id');
        $new_status = $request->get_param('new_status');

        if (!$order_id || !$new_status) {
            // Error message for missing parameters
            $missing_params_message = 'Required parameters not provided';
            custom_error_logger($missing_params_message);
            return new WP_REST_Response($missing_params_message, 400);
        }

        $order = wc_get_order($order_id);
        if ($order) {
            $order->update_status($new_status);
            // Order status updated message
            $order_status_updated_message = "Order status updated for order_id: $order_id to status: $new_status";
            custom_error_logger($order_status_updated_message);
            return new WP_REST_Response('Order status updated', 200);
        } else {
            // Invalid order ID message
            $invalid_order_id_message = 'Invalid order ID';
            custom_error_logger($invalid_order_id_message);
            return new WP_REST_Response($invalid_order_id_message, 400);
        }
    } catch (Exception $e) {
        // Error message for exception
        $exception_message = 'Error in update_order_status_callback: ' . $e->getMessage();
        custom_error_logger($exception_message);
        return new WP_REST_Response('Internal server error', 500);
    }
}

// Replace the original callback with the safe version
add_action('rest_api_init', function() {
    register_rest_route('custom/v1', '/update_order_status/', array(
        'methods'  => 'POST',
        'callback' => 'safe_update_order_status_callback',
        'permission_callback' => '__return_true',
    ));
});

// update for those who cannot use the above code
function ensure_updated_callback( WP_REST_Request $request ) {
    $params = $request->get_params();
    $order_id = $request->get_param('order_id'); // This is the *main* order ID
    
    // Log message for received status update request
    $req_recv_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [Order:'.$order_id.'] [REQ_RECVD] Received status update request.';
    custom_error_logger($req_recv_message);
    
    // Log message for request parameters
    $req_params_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [Order:'.$order_id.'] [REQ_PARAMS] Params: ' . json_encode($params);
    custom_error_logger($req_params_message);
    
    $new_status = $request->get_param('new_status');
    $user_id    = $request->get_param('user_id');
    $payment_id = $request->get_param('payment_id');
    $provider   = $request->get_param('provider');

    if (!$order_id || !$new_status ) {
        // Log message for missing required parameters
        $missing_params_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [Order:'.$order_id.'] [VALIDATION_ERR] Missing required parameters.';
        custom_error_logger($missing_params_message);
        return new WP_REST_Response('Missing required parameters', 400);
    }

    $order = wc_get_order($order_id);
    
    if ($order) {
        $new_status = $new_status ? 'processing' : 'pending_payment';
        $wc_order_id = $order->get_id(); // Get the actual WC order ID
        
        // Store payment gateway info in order meta
        if ($payment_id) {
            // Log message for adding payment_id
            $add_payment_id_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [WC_Order:'.$wc_order_id.'] [META_UPDATE] Adding payment_id: ' . $payment_id;
            custom_error_logger($add_payment_id_message);
            $order->update_meta_data('payment_id', $payment_id);
        }
        if ($provider) {
            // Log message for adding payment_provider
            $add_payment_provider_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [WC_Order:'.$wc_order_id.'] [META_UPDATE] Adding payment_provider: ' . $provider;
            custom_error_logger($add_payment_provider_message);
            $order->update_meta_data('payment_provider', $provider);
        }
        
        // Mark the order as updated via push to avoid redundant pulls
        $order->update_meta_data('updated_via_push', 'yes');
        $order->update_meta_data('last_status_update_time', current_time('timestamp'));
        $order->save_meta_data();
        
        // Log message for updating status
        $updating_status_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [WC_Order:'.$wc_order_id.'] [UPDATE_STATUS] Updating status to: ' . $new_status;
        custom_error_logger($updating_status_message);
        $order->update_status($new_status);
        
        // Log message for successful status update
        $update_success_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [WC_Order:'.$wc_order_id.'] [UPDATE_SUCCESS] Status updated.';
        custom_error_logger($update_success_message);
        
        // Log message for order status updated details
        $update_details_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [WC_Order:'.$wc_order_id.'] [UPDATE_DETAILS] Order status updated by user: ' . $user_id . ', Provider: ' . ($provider ?? 'Unknown');
        custom_error_logger($update_details_message);

        return new WP_REST_Response('Order status updated', 200);
    } else {
        // Log message for order not found
        $order_not_found_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusUpdate] [Order:'.$order_id.'] [ORDER_ERR] Order not found.';
        custom_error_logger($order_not_found_message);
        return new WP_REST_Response('Invalid order ID', 400);
    }
}

function register_ensure_updated_endpoint() {
    register_rest_route('custom/v1', '/ensure_updated/', array(
        'methods'  => 'GET',
        'callback' => 'ensure_updated_callback',
        'permission_callback' => '__return_true',
    ));
}

add_action('rest_api_init', 'register_ensure_updated_endpoint');

// Improved version of fetch_and_update_order_status_from_link
function fetch_and_update_order_status_from_link($order_id_wc) {
    $order_wc = wc_get_order($order_id_wc);
    if (!$order_wc) {
        // Log message for WC Order not found
        $wc_order_not_found_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [ORDER_ERR] WC Order not found.';
        custom_error_logger($wc_order_not_found_message);
        return;
    }

    // Don't pull if the order is already processing or completed
    if (in_array($order_wc->get_status(), ['processing', 'completed'])) {
        // Log message for skipping pull due to order status
        $pull_skip_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [PULL_SKIP] Order already in final status: ' . $order_wc->get_status();
        custom_error_logger($pull_skip_message);
        return;
    }
    
    // Check if order was recently updated via push
    $updated_via_push = $order_wc->get_meta('updated_via_push', true);
    $last_update_time = intval($order_wc->get_meta('last_status_update_time', true));
    $current_time = current_time('timestamp');
    $five_minutes = 5 * 60; // 5 minutes in seconds
    
    // Skip pull if order was updated via push in the last 5 minutes
    if ($updated_via_push === 'yes' && ($current_time - $last_update_time) < $five_minutes) {
        // Log message for skipping pull due to recent push update
        $pull_skip_recent_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [PULL_SKIP] Recently updated via push: ' . 
            round(($current_time - $last_update_time)/60, 1) . ' minutes ago';
        custom_error_logger($pull_skip_recent_message);
        return;
    }

    $original_order_id = $order_wc->get_id(); // Using WC order ID directly if it matches main_order_id

    // Log message for initiating status pull
    $pull_start_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [PULL_START] Initiating status pull from Link server.';
    custom_error_logger($pull_start_message);

    global $wpdb;
    $settings_table = $wpdb->prefix . 'mtjree_company_db';
    $settings = $wpdb->get_row("SELECT api_key FROM $settings_table LIMIT 1");
    $api_key = $settings->api_key ?? null;

    if (empty($api_key)) {
        // Log message for API Key not found
        $api_err_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [API_ERR] API Key not found in client settings.';
        custom_error_logger($api_err_message);
        return;
    }

    $client_domain = parse_url(site_url(), PHP_URL_HOST);
    $target_url = add_query_arg([
        'order_id' => $original_order_id,
        'domain' => $client_domain,
    ], 'https://mtjree.link/wp-json/operations-manager/v1/get-order-status');

    // Log message for sending request
    $send_req_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [SEND_REQ] Sending request to: ' . $target_url;
    custom_error_logger($send_req_message);

    $response = wp_remote_get($target_url, [
        'timeout' => 20,
        'headers' => [
            'Authorization' => 'Bearer ' . $api_key,
            'Accept' => 'application/json',
        ],
    ]);

    if (is_wp_error($response)) {
        // Log message for response error
        $resp_err_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [RESP_ERR] Error: ' . $response->get_error_message();
        custom_error_logger($resp_err_message);
        return;
    }

    $http_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // Log message for received response
    $resp_recv_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [RESP_RECV] Code='.$http_code.', Body='.$body;
    custom_error_logger($resp_recv_message);

    if ($http_code === 200 && isset($data['status']) && $data['status'] === true) {
        // Check current status to avoid unnecessary updates
        if ($order_wc->get_status() !== 'processing' && $order_wc->get_status() !== 'completed') {
            // Get additional payment details if available
            $payment_id = $data['payment_id'] ?? null;
            $provider = $data['provider'] ?? null;
            
            // Store payment info in order meta
            if ($payment_id) {
                // Log message for adding payment_id
                $add_payment_id_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [META_UPDATE] Adding payment_id: ' . $payment_id;
                custom_error_logger($add_payment_id_message);
                $order_wc->update_meta_data('payment_id', $payment_id);
            }
            if ($provider) {
                // Log message for adding payment_provider
                $add_payment_provider_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [META_UPDATE] Adding payment_provider: ' . $provider;
                custom_error_logger($add_payment_provider_message);
                $order_wc->update_meta_data('payment_provider', $provider);
            }
            
            // Mark as updated via pull
            $order_wc->update_meta_data('updated_via_pull', 'yes');
            $order_wc->update_meta_data('last_status_update_time', current_time('timestamp'));
            $order_wc->save_meta_data();
            
            // Log message for updating to processing
            $updating_to_processing_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [UPDATE_STATUS] Updating to: processing';
            custom_error_logger($updating_to_processing_message);
            $order_wc->update_status('processing', 'Order status updated via pull from mtjree.link.');
            
            // Log message for successful status update to processing
            $update_success_processing_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [UPDATE_SUCCESS] Status updated to processing.';
            custom_error_logger($update_success_processing_message);
        } else {
            // Log message for skipping update due to order status
            $update_skip_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [UPDATE_SKIP] Order already in final status: ' . $order_wc->get_status();
            custom_error_logger($update_skip_message);
        }
    } elseif ($http_code !== 200) {
        // Log message for HTTP error
        $http_error_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [RESP_ERR] HTTP Code: '.$http_code.', Message: ' . ($data['message'] ?? 'Unknown error');
        custom_error_logger($http_error_message);
    } elseif (isset($data['status']) && $data['status'] === false) {
        // Log message for payment not completed
        $payment_not_completed_message = '['.date('Y-m-d H:i:s').'] [SUP] [StatusPull] [Order:'.$order_id_wc.'] [STATUS_CHECK] Payment not completed on Link server.';
        custom_error_logger($payment_not_completed_message);
    }
}

// Also check status on the success page after payment return
add_action('template_redirect', 'check_order_status_on_success_page');

function check_order_status_on_success_page() {
    global $wpdb;
    
    // Get the success page URL from the database
    $table = $wpdb->prefix . 'mtjree_company_db';
    $success_page = $wpdb->get_var("SELECT redirect_succes_page FROM $table WHERE id = 1");
    
    // If no success page defined, return
    if (empty($success_page)) {
        return;
    }
    
    // Check if we're on the success page
    $current_url_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $success_page_path = parse_url($success_page, PHP_URL_PATH);
    
    if ($current_url_path !== $success_page_path) {
        return;
    }
    
    // Log message for starting check on success page
    $check_start_message = '['.date('Y-m-d H:i:s').'] [SUP] [SuccessPage] [CHECK_START] On success page - checking for order.';
    custom_error_logger($check_start_message);
    
    // Try to get the order ID from URL parameters
    $order_id = 0;
    if (isset($_GET['order_id'])) {
        $order_id = intval($_GET['order_id']);
        // Log message for found order_id in URL params
        $param_found_message = '['.date('Y-m-d H:i:s').'] [SUP] [SuccessPage] [PARAM_FOUND] Found order_id='.$order_id.' in URL params.';
        custom_error_logger($param_found_message);
    } elseif (isset($_GET['key']) && !empty($_GET['key'])) {
        // Try to get order by order key
        $order_key = wc_clean($_GET['key']);
        $order_id = wc_get_order_id_by_order_key($order_key);
        // Log message for found order key in URL
        $key_found_message = '['.date('Y-m-d H:i:s').'] [SUP] [SuccessPage] [KEY_FOUND] Found order key in URL, resolved to order_id='.$order_id;
        custom_error_logger($key_found_message);
    } elseif (WC()->session) {
        // Try to get from session
        $order_id = WC()->session->get('last_order_id');
        if ($order_id) {
            // Log message for found order_id in session
            $session_found_message = '['.date('Y-m-d H:i:s').'] [SUP] [SuccessPage] [SESSION_FOUND] Found order_id='.$order_id.' in session.';
            custom_error_logger($session_found_message);
        }
    }
    
    // If we have an order ID, check its status
    if ($order_id > 0) {
        $order = wc_get_order($order_id);
        if ($order) {
            // Log message for current status
            $check_status_message = '['.date('Y-m-d H:i:s').'] [SUP] [SuccessPage] [Order:'.$order_id.'] [CHECK_STATUS] Current status: '.$order->get_status();
            custom_error_logger($check_status_message);
            fetch_and_update_order_status_from_link($order_id);
        } else {
            // Log message for order not found in system
            $order_not_found_message = '['.date('Y-m-d H:i:s').'] [SUP] [SuccessPage] [Order:'.$order_id.'] [ORDER_ERR] Order not found in system.';
            custom_error_logger($order_not_found_message);
        }
    } else {
        // Log message for no order ID found
        $no_order_id_message = '['.date('Y-m-d H:i:s').'] [SUP] [SuccessPage] [ORDER_ERR] No order ID found on success page.';
        custom_error_logger($no_order_id_message);
    }
}

// Add scheduled task for checking pending orders
add_action('init', 'register_pending_orders_cron');
function register_pending_orders_cron() {
    if (!wp_next_scheduled('check_pending_orders_status')) {
        wp_schedule_event(time(), 'hourly', 'check_pending_orders_status');
        // Log message for registered pending orders check cron
        $setup_message = '['.date('Y-m-d H:i:s').'] [SUP] [Cron] [SETUP] Registered pending orders check cron.';
        custom_error_logger($setup_message);
    }
}

// Handle the scheduled task
add_action('check_pending_orders_status', 'check_pending_orders_status_function');
function check_pending_orders_status_function() {
    // Log message for starting pending orders check
    $run_start_message = '['.date('Y-m-d H:i:s').'] [SUP] [Cron] [RUN_START] Starting pending orders check.';
    custom_error_logger($run_start_message);
    
    // Query for pending orders older than 5 minutes but less than 24 hours
    $args = array(
        'status' => 'pending',
        'date_created' => '>' . (time() - 86400), // Last 24 hours
        'limit' => 20, // Process in batches to avoid timeouts
    );
    
    $orders = wc_get_orders($args);
    $count = count($orders);
    
    // Log message for found pending orders to check
    $orders_found_message = '['.date('Y-m-d H:i:s').'] [SUP] [Cron] [ORDERS_FOUND] Found ' . $count . ' pending orders to check.';
    custom_error_logger($orders_found_message);
    
    $updated_count = 0;
    
    foreach ($orders as $order) {
        $order_id = $order->get_id();
        $order_created_time = $order->get_date_created()->getTimestamp();
        $current_time = current_time('timestamp');
        $time_diff_minutes = round(($current_time - $order_created_time) / 60);
        
        // Only check orders older than 5 minutes (to give push a chance to work)
        if ($time_diff_minutes < 5) {
            // Log message for skipping recent order
            $skip_recent_message = '['.date('Y-m-d H:i:s').'] [SUP] [Cron] [Order:'.$order_id.'] [SKIP_RECENT] Order too recent ('.$time_diff_minutes.' mins old).';
            custom_error_logger($skip_recent_message);
            continue;
        }
        
        // Check if already checked in the last hour via pull
        $last_pull_check = intval($order->get_meta('last_pull_check_time', true));
        if ($last_pull_check > 0 && ($current_time - $last_pull_check) < 3600) {
            // Log message for skipping already checked order
            $skip_checked_message = '['.date('Y-m-d H:i:s').'] [SUP] [Cron] [Order:'.$order_id.'] [SKIP_CHECKED] Already checked ' . 
                round(($current_time - $last_pull_check)/60, 1) . ' mins ago.';
            custom_error_logger($skip_checked_message);
            continue;
        }
        
        // Log message for checking pending order
        $check_start_message = '['.date('Y-m-d H:i:s').'] [SUP] [Cron] [Order:'.$order_id.'] [CHECK_START] Checking pending order '.$time_diff_minutes.' mins old.';
        custom_error_logger($check_start_message);
        $order->update_meta_data('last_pull_check_time', $current_time);
        $order->save_meta_data();
        
        // Use the same pull function as other places
        fetch_and_update_order_status_from_link($order_id);
        
        // Only count as updated if status is no longer pending
        if ($order->get_status() !== 'pending') {
            $updated_count++;
        }
    }
    
    // Log message for finished checking orders
    $run_complete_message = '['.date('Y-m-d H:i:s').'] [SUP] [Cron] [RUN_COMPLETE] Finished checking ' . $count . ' orders. Updated: ' . $updated_count;
    custom_error_logger($run_complete_message);
}

// Add cleanup for the cron job on plugin deactivation
register_deactivation_hook(__FILE__, 'deactivate_pending_orders_cron');
function deactivate_pending_orders_cron() {
    wp_clear_scheduled_hook('check_pending_orders_status');
    // Log message for cleared pending orders cron job
    $cleanup_message = '['.date('Y-m-d H:i:s').'] [SUP] [Cron] [CLEANUP] Cleared pending orders cron job.';
    custom_error_logger($cleanup_message);
}

// Add settings page
add_action('admin_menu', 'mtjree_settings_menu');

function mtjree_settings_menu() {
    add_menu_page(
        'MTJREE Settings',
        'MTJREE Settings',
        'manage_options',
        'mtjree-settings',
        'mtjree_settings_page',
        'dashicons-admin-generic',
        100
    );
}


if (!function_exists('mtjree_settings_page')) {
    function mtjree_settings_page() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'mtjree_company_db';

        // Ensure the row with ID=1 exists before proceeding
        $row_exists = $wpdb->get_row("SELECT id FROM $table_name WHERE id = 1");
        if (!$row_exists) {
            // Attempt to insert the default row if it's missing
            $wpdb->insert(
                $table_name,
                array(
                    'id' => 1, // Explicitly set ID to 1
                    'api_key' => '',
                    'redirect_succes_page' => '',
                    'redirect_fail_page' => '',
                    'vendor_name' => '',
                    'logo_url' => '',
                    'enable_test_mode' => 0,
                ),
                array( // Specify formats for the insert data
                    '%d', '%s', '%s', '%s', '%s', '%s', '%d'
                )
            );
             // Log if insertion failed
            if ($wpdb->last_error) {
                 custom_error_logger("MTJREE Settings Error: Failed to insert default row. DB Error: " . $wpdb->last_error);
                 echo '<div class="notice notice-error"><p>Error initializing settings. Please check logs or reactivate the plugin.</p></div>';
            } else {
                 custom_error_logger("MTJREE Settings Info: Default settings row created.");
            }
        }


        // Handle update settings
        if (isset($_POST['update_settings'])) {
            if (!isset($_POST['mtjree_settings_nonce']) || !wp_verify_nonce($_POST['mtjree_settings_nonce'], 'mtjree_update_settings_action')) {
                echo '<div class="notice notice-error"><p>Security check failed. Please try again.</p></div>';
            } else {
                // Sanitize input data
                $api_key = sanitize_text_field($_POST['api_key']);
                $redirect_succes_page = sanitize_text_field($_POST['redirect_succes_page']);
                $redirect_fail_page = sanitize_text_field($_POST['redirect_fail_page']);
                $vendor_name = sanitize_text_field($_POST['vendor_name']);
                $logo_url = sanitize_text_field($_POST['logo_url']);
                $enable_test_mode = isset($_POST['enable_test_mode']) ? 1 : 0;
                
                // Fetch current settings to compare
                $current_settings = $wpdb->get_row("SELECT * FROM $table_name WHERE id = 1", ARRAY_A);
                
                // Check if there are actual changes
                $has_changes = false;
                if ($current_settings) {
                    if ($current_settings['api_key'] != $api_key || 
                        $current_settings['redirect_succes_page'] != $redirect_succes_page ||
                        $current_settings['redirect_fail_page'] != $redirect_fail_page ||
                        $current_settings['vendor_name'] != $vendor_name ||
                        $current_settings['logo_url'] != $logo_url ||
                        $current_settings['enable_test_mode'] != $enable_test_mode) {
                        $has_changes = true;
                    }
                } else {
                    $has_changes = true; // If no current settings, consider it a change
                }

                if ($has_changes) {
                    $result = $wpdb->update(
                        $table_name,
                        array(
                            'api_key' => $api_key,
                            'redirect_succes_page' => $redirect_succes_page,
                            'redirect_fail_page' => $redirect_fail_page,
                            'vendor_name' => $vendor_name,
                            'logo_url' => $logo_url,
                            'enable_test_mode' => $enable_test_mode,
                        ),
                        array('id' => 1), // Always update row with id=1
                        array('%s', '%s', '%s', '%s', '%s', '%d'), // Format of data being updated
                        array('%d') // Format of WHERE clause
                    );

                    if ($result === false) {
                        // Database error occurred
                        echo '<div class="notice notice-error"><p>Error updating settings: ' . $wpdb->last_error . '</p></div>';
                        custom_error_logger("MTJREE Settings Update Error: " . $wpdb->last_error);
                    } else {
                        // Settings were successfully updated
                        echo '<div class="notice notice-success"><p>Settings updated successfully!</p></div>';
                        custom_error_logger("MTJREE Settings Info: Settings updated successfully.");
                    }
                } else {
                    // Check if we need to force an update even though values are the same
                    // This ensures the row exists and has proper format
                    $result = $wpdb->update(
                        $table_name,
                        array(
                            'api_key' => $api_key,
                            'redirect_succes_page' => $redirect_succes_page,
                            'redirect_fail_page' => $redirect_fail_page,
                            'vendor_name' => $vendor_name,
                            'logo_url' => $logo_url,
                            'enable_test_mode' => $enable_test_mode,
                        ),
                        array('id' => 1),
                        array('%s', '%s', '%s', '%s', '%s', '%d'),
                        array('%d')
                    );
                    
                    // No changes detected
                    echo '<div class="notice notice-info"><p>No changes detected in settings values.</p></div>';
                }
            }
        }

        // Fetch settings
        $settings = $wpdb->get_row("SELECT * FROM $table_name WHERE id = 1");
        $api_key = $settings->api_key ?? '';
        $redirect_succes_page = $settings->redirect_succes_page ?? '';
        $redirect_fail_page = $settings->redirect_fail_page ?? '';
        $vendor_name = $settings->vendor_name ?? '';
        $logo_url = $settings->logo_url ?? '';
        $enable_test_mode = $settings->enable_test_mode ?? 0;
        $pages = get_pages();
        ?>
        <div class="wrap">
            <h1>MTJREE Settings</h1>
            <form method="post">
                <?php wp_nonce_field('mtjree_update_settings_action', 'mtjree_settings_nonce'); ?>
                <table class="form-table">
                <tr>
                        <th scope="row">Enable Test Mode</th>
                        <td><input type="checkbox" name="enable_test_mode" <?php echo $enable_test_mode ? 'checked' : ''; ?>></td>
                    </tr>
                    <tr>
                        <th scope="row">Vendor Name</th>
                        <td><input type="text" name="vendor_name" value="<?php echo esc_attr($vendor_name); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row">API Key</th>
                        <td><input type="text" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th scope="row">Logo</th>
                        <td>
                            <input type="hidden" name="logo_url" id="logo_url" value="<?php echo esc_attr($logo_url); ?>">
                            <button type="button" class="button" id="upload_logo_button">Upload Logo</button>
                            <div id="logo_preview" style="margin-top: 10px;">
                                <?php if (!empty($logo_url)): ?>
                                    <img src="<?php echo esc_url($logo_url); ?>" alt="Logo" style="max-width: 150px;">
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Redirect Success Page</th>
                        <td>
                            <select name="redirect_succes_page">
                                <?php foreach ($pages as $page): ?>
                                    <option value="<?php echo esc_url(get_permalink($page->ID)); ?>"
                                        <?php selected($redirect_succes_page, get_permalink($page->ID)); ?>>
                                        <?php echo esc_html($page->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Redirect Fail Page</th>
                        <td>
                            <select name="redirect_fail_page">
                                <?php foreach ($pages as $page): ?>
                                    <option value="<?php echo esc_url(get_permalink($page->ID)); ?>"
                                        <?php selected($redirect_fail_page, get_permalink($page->ID)); ?>>
                                        <?php echo esc_html($page->post_title); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Update Settings', 'primary', 'update_settings'); ?>
            </form>
        </div>
        <script>
            jQuery(document).ready(function ($) {
                var mediaUploader;
                $('#upload_logo_button').click(function (e) {
                    e.preventDefault();
                    if (mediaUploader) {
                        mediaUploader.open();
                        return;
                    }
                    mediaUploader = wp.media({
                        title: 'Select Logo',
                        button: {
                            text: 'Use this logo'
                        },
                        multiple: false
                    });
                    mediaUploader.on('select', function () {
                        var attachment = mediaUploader.state().get('selection').first().toJSON();
                        $('#logo_url').val(attachment.url);
                        $('#logo_preview').html('<img src="' + attachment.url + '" alt="Logo" style="max-width: 150px;">');
                    });
                    mediaUploader.open();
                });
            });
        </script>
        <?php
    }
}
function mtjree_enqueue_admin_scripts($hook) {
    if ($hook !== 'toplevel_page_mtjree-settings') {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script('jquery');
}
add_action('admin_enqueue_scripts', 'mtjree_enqueue_admin_scripts');
