const settings = window.wc.wcSettings.getSetting('my_custom_gateway_data', {});

console.log('Settings:', settings); // Log the settings object to the console

const iconUrl = settings.icon_url || ''; // Ensure icon_url is correctly populated in settings
console.log('Icon URL:', iconUrl); // Log the icon URL to the console

const title = window.wp.htmlEntities.decodeEntities(settings.title) || window.wp.i18n.__('My Custom Gateway', 'my_custom_gateway');
console.log('Title:', title); // Log the title to the console

const Label = () => {
    return window.wp.element.createElement('span', {
    style : {
        display:"block",
        position : "relative",
        width : "100%",
    },
    },
    title,
        window.wp.element.createElement('img', {
            src: iconUrl,
            alt: 'Credit Card Icon',
            style: {
                    float :`${document.documentElement.lang === "ar"?"left":"right"}`
                }
        }),
    );
};

const Content = () => {
    return window.wp.htmlEntities.decodeEntities(settings.description || '');
};

const Block_Gateway = {
    name: 'my_custom_gateway',
    label: Object(window.wp.element.createElement)(Label, null),
    content: Object(window.wp.element.createElement)(Content, null),
    edit: Object(window.wp.element.createElement)(Content, null),
    canMakePayment: () => true,
    ariaLabel: title,
    supports: {
        features: settings.supports,
    },
};

console.log('Block Gateway:', Block_Gateway); // Log the Block Gateway object to the console

window.wc.wcBlocksRegistry.registerPaymentMethod(Block_Gateway);
